#!/bin/sh
java -jar start.jar